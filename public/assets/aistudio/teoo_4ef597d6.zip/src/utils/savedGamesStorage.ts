import { GameSequenceItem, SheetViewType, BingoMode, BingoSheetData, Traditional90SheetData, AppUser } from '../types';
import { doc, setDoc, serverTimestamp, deleteDoc, collection, getDocs, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { safeSetItem, sanitizeSequenceForStorage, cleanupLocalStorageForQuota } from './safeStorage';

export const STORAGE_KEY_SAVED_GAMES_GALLERY = 'bingo_saved_games_gallery';
export const STORAGE_KEY_SEQUENCE_75 = 'bingo_game_sequence_history';
export const STORAGE_KEY_SEQUENCE_90 = 'bingo_90_game_sequence_history';

/**
 * Scopes a localStorage key to a specific user/operator so their sequence,
 * custom marks and state are 100% individual and never mixed with another user.
 */
export function getOperatorStorageKey(baseKey: string, user?: AppUser | null): string {
  if (!user) return baseKey;
  const id = user.id || user.uid || (user.email ? user.email.replace(/[^a-zA-Z0-9_-]/g, '_') : 'anon');
  return `${baseKey}_${id}`;
}

/**
 * Checks whether a saved game belongs to a specific operator or user session.
 * Used to strictly separate operator sequence, stats, and gallery views.
 */
export function isGameOfOperator(
  game: GameSequenceItem,
  user?: AppUser | null
): boolean {
  if (!user) return true; // Default fallback if no operator profile is signed in
  if (user.role === 'admin') return true; // Administrators see all games from all operators

  const opUid = user.id || user.uid;
  const opEmail = user.email ? user.email.trim().toLowerCase() : '';
  const opName = user.name ? user.name.trim().toLowerCase() : '';

  if (game.operatorUid && opUid && (game.operatorUid === opUid || game.operatorUid === user.id || game.operatorUid === user.uid)) {
    return true;
  }

  if (game.operatorEmail && opEmail && game.operatorEmail.trim().toLowerCase() === opEmail) {
    return true;
  }

  if (game.operatorName && opName && game.operatorName.trim().toLowerCase() === opName) {
    return true;
  }

  // If game has NO operator identification attached, assume it belongs to local machine session
  if (!game.operatorUid && !game.operatorEmail && !game.operatorName) {
    return true;
  }

  return false;
}

/**
 * Real-time listener for Firestore saved_games collection
 * Keeps all saved games from all operators synchronized across all devices
 */
export function subscribeToSavedGamesFirestore(
  callback: (games: GameSequenceItem[]) => void
): () => void {
  if (typeof window === 'undefined') {
    return () => {};
  }

  try {
    const q = collection(db, 'saved_games');
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const remoteMap = new Map<string, GameSequenceItem>();
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as GameSequenceItem;
          const key = data.id || docSnap.id;
          remoteMap.set(key, { ...data, id: key });
        });

        // Merge with existing local storage items to prevent losing newly drafted items
        const localList = getSavedGamesGallery();
        localList.forEach((localItem) => {
          if (!localItem) return;
          const key = localItem.id || `game_${localItem.round}_${localItem.mode || localItem.sheetType}`;
          if (!remoteMap.has(key)) {
            remoteMap.set(key, localItem);
          }
        });

        const merged = Array.from(remoteMap.values());
        merged.sort((a, b) => {
          if (b.round !== a.round) {
            return (b.round || 0) - (a.round || 0);
          }
          return 0;
        });

        // Cache locally using safeSetItem (stripping heavy base64 images from older games)
        const galleryToStore = merged.map((g, idx) => {
          if (idx > 1 && g.cageSnapshotImage) {
            const copy = { ...g };
            delete copy.cageSnapshotImage;
            return copy;
          }
          return g;
        });
        safeSetItem(STORAGE_KEY_SAVED_GAMES_GALLERY, JSON.stringify(galleryToStore));

        callback(merged);
      },
      (error) => {
        console.warn('Firestore saved_games subscription error:', error);
      }
    );

    return unsubscribe;
  } catch (err) {
    console.warn('Could not initialize saved_games subscription:', err);
    return () => {};
  }
}

/**
 * Get all saved games from gallery storage, merged and unified with sequence histories
 */
export function getSavedGamesGallery(): GameSequenceItem[] {
  if (typeof window === 'undefined') return [];

  const map = new Map<string, GameSequenceItem>();

  // 1. Load from dedicated saved games gallery
  const hasSavedGalleryKey = localStorage.getItem(STORAGE_KEY_SAVED_GAMES_GALLERY) !== null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SAVED_GAMES_GALLERY);
    if (raw) {
      const parsed: GameSequenceItem[] = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach((item) => {
          if (!item) return;
          if (!item.round || item.round < 1) return;

          const key = item.id || `game_${item.round}_${item.mode || item.sheetType}`;
          map.set(key, item);
        });
      }
    }
  } catch (e) {
    console.error('Error reading saved games gallery', e);
  }

  const allItems = Array.from(map.values());

  // Sort descending by round & time so the most recent is top in gallery
  allItems.sort((a, b) => {
    if (b.round !== a.round) {
      return (b.round || 0) - (a.round || 0);
    }
    return 0;
  });

  return allItems;
}

/**
 * Purge any ghost/fake games with ball 0 or empty balls from all local storage keys
 */
export function purgeGhostGamesFromStorage(): void {
  if (typeof window === 'undefined') return;
  try {
    const rawGallery = localStorage.getItem(STORAGE_KEY_SAVED_GAMES_GALLERY);
    if (rawGallery) {
      const parsed = JSON.parse(rawGallery);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter(
          (item) => item && typeof item.round === 'number' && item.round >= 1
        );
        localStorage.setItem(STORAGE_KEY_SAVED_GAMES_GALLERY, JSON.stringify(cleaned));
      }
    }
    const raw75 = localStorage.getItem(STORAGE_KEY_SEQUENCE_75);
    if (raw75) {
      const parsed = JSON.parse(raw75);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter(
          (item) => item && typeof item.round === 'number' && item.round >= 1
        );
        localStorage.setItem(STORAGE_KEY_SEQUENCE_75, JSON.stringify(cleaned));
      }
    }
    const raw90 = localStorage.getItem(STORAGE_KEY_SEQUENCE_90);
    if (raw90) {
      const parsed = JSON.parse(raw90);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter(
          (item) => item && typeof item.round === 'number' && item.round >= 1
        );
        localStorage.setItem(STORAGE_KEY_SEQUENCE_90, JSON.stringify(cleaned));
      }
    }
    const rawCustom = localStorage.getItem('bingo_sheet_custom_sequence');
    if (rawCustom) {
      const parsed = JSON.parse(rawCustom);
      if (parsed && typeof parsed === 'object') {
        const cleanedObj: Record<string, any> = {};
        Object.entries(parsed).forEach(([k, v]: [string, any]) => {
          if (v && (Number(v.bingo) > 0 || Number(v.terna) > 0 || Number(v.ambo) > 0)) {
            cleanedObj[k] = v;
          }
        });
        localStorage.setItem('bingo_sheet_custom_sequence', JSON.stringify(cleanedObj));
      }
    }
  } catch (e) {
    console.error('Error purging ghost games from storage', e);
  }
}

/**
 * Save a new or updated game snapshot to Firestore and the gallery, synchronizing both areas
 */
export async function saveGameToFirestoreAndGallery(item: GameSequenceItem): Promise<void> {
  if (!item) {
    console.warn('Rejected saving empty game');
    return;
  }

  const validRound = typeof item.round === 'number' && item.round >= 1 ? item.round : 1;
  const normalizedItem: GameSequenceItem = {
    ...item,
    round: validRound,
    dailyDate: item.dailyDate || new Date().toISOString().split('T')[0],
    dateFormatted: item.dateFormatted || new Date().toLocaleDateString('es-ES'),
  };

  saveGameToGallery(normalizedItem);

  // Firestore remote persistence
  try {
    const docId = normalizedItem.id || `game_${Date.now()}_${normalizedItem.round}`;
    const dailyDate = normalizedItem.dailyDate || new Date().toISOString().split('T')[0];
    const drawnBalls = normalizedItem.drawnBallsPlayed || [];

    const firestorePayload: any = {
      id: docId,
      round: normalizedItem.round,
      ballNumber: normalizedItem.ballNumber || 0,
      letter: normalizedItem.letter || '',
      mode: normalizedItem.mode || '75',
      timestamp: normalizedItem.timestamp || new Date().toLocaleTimeString(),
      dateFormatted: normalizedItem.dateFormatted || new Date().toLocaleDateString('es-ES'),
      dailyDate,
      operatorUid: normalizedItem.operatorUid || 'anon',
      operatorName: (normalizedItem.operatorName || 'Operadora Principal').trim(),
      operatorEmail: normalizedItem.operatorEmail || '',
      durationSeconds: normalizedItem.durationSeconds || 0,
      durationFormatted: normalizedItem.durationFormatted || '0s',
      totalCollected: normalizedItem.totalCollected || 0,
      totalPrizesPaid: normalizedItem.totalPrizesPaid || 0,
      netProfit: normalizedItem.netProfit || 0,
      currency: normalizedItem.currency || '$',
      drawnBallsPlayed: drawnBalls,
      totalBallsDrawnCount: drawnBalls.length || normalizedItem.totalBallsDrawnCount || 0,
      rowLeader: normalizedItem.rowLeader ?? null,
      winningPlayerName: normalizedItem.winningPlayerName || '',
      tableNumber: normalizedItem.tableNumber ?? null,
      sheetType: normalizedItem.sheetType || (normalizedItem.mode === '90' ? 'traditional-90' : 'multipliers-15'),
      totalLinesPlayed: normalizedItem.totalLinesPlayed !== undefined ? normalizedItem.totalLinesPlayed : (normalizedItem.sheetType === 'traditional-90' ? 60 : 90),
      cageSnapshotImage: normalizedItem.cageSnapshotImage || null,
      createdAt: serverTimestamp(),
      savedAtISO: new Date().toISOString(),
    };

    if (normalizedItem.playerSummarySnapshot && Array.isArray(normalizedItem.playerSummarySnapshot)) {
      firestorePayload.playerSummarySnapshot = JSON.parse(JSON.stringify(normalizedItem.playerSummarySnapshot));
    }
    if (normalizedItem.sequenceSnapshot) {
      firestorePayload.sequenceSnapshot = JSON.parse(JSON.stringify(normalizedItem.sequenceSnapshot));
    }

    // If sheet snapshots exist, include serialized summary
    if (normalizedItem.sheet75Snapshot) {
      const s75Copy = JSON.parse(JSON.stringify(normalizedItem.sheet75Snapshot));
      if (normalizedItem.playerSummarySnapshot && (!s75Copy.playerSummaryList || s75Copy.playerSummaryList.length === 0)) {
        s75Copy.playerSummaryList = normalizedItem.playerSummarySnapshot;
      }
      firestorePayload.sheet75Snapshot = s75Copy;
    }
    if (normalizedItem.sheet90Snapshot) {
      firestorePayload.sheet90Snapshot = JSON.parse(JSON.stringify(normalizedItem.sheet90Snapshot));
    }

    await setDoc(doc(db, 'saved_games', docId), firestorePayload);
  } catch (err) {
    console.warn('Could not save game to Firestore:', err);
  }
}

/**
 * Save a new or updated game snapshot to the gallery and synchronize both areas
 */
export function saveGameToGallery(item: GameSequenceItem): void {
  if (typeof window === 'undefined' || !item) return;
  const validRound = typeof item.round === 'number' && item.round >= 1 ? item.round : 1;

  try {
    const current = getSavedGamesGallery();
    const mode = item.mode || (item.sheetType === 'traditional-90' ? '90' : '75');
    const normalizedItem: GameSequenceItem = {
      ...item,
      id: item.id || `game_${Date.now()}_${item.round}_${mode}`,
      dailyDate: item.dailyDate || new Date().toISOString().split('T')[0],
      operatorName: (item.operatorName || 'Operadora Principal').trim(),
      operatorEmail: item.operatorEmail || '',
      operatorUid: item.operatorUid || 'anon',
      mode,
    };

    // Check if an item with identical id or same round + mode already exists
    const existingIdx = current.findIndex(
      (g) =>
        (g.id && g.id === normalizedItem.id) ||
        (g.round === normalizedItem.round && (g.mode === mode || g.sheetType === normalizedItem.sheetType))
    );

    let updated: GameSequenceItem[];
    if (existingIdx >= 0) {
      updated = [...current];
      updated[existingIdx] = { ...current[existingIdx], ...normalizedItem };
    } else {
      updated = [normalizedItem, ...current];
    }

    // Save main gallery safely (keeps image only on top 2 most recent items locally)
    const galleryToStore = updated.map((g, idx) => {
      if (idx > 1 && g.cageSnapshotImage) {
        const copy = { ...g };
        delete copy.cageSnapshotImage;
        return copy;
      }
      return g;
    });
    safeSetItem(STORAGE_KEY_SAVED_GAMES_GALLERY, JSON.stringify(galleryToStore));

    // Dispatch global event so all UI components update counters and tables immediately
    window.dispatchEvent(
      new CustomEvent('bingo_saved_games_updated', {
        detail: { total: updated.length, savedItem: normalizedItem },
      })
    );
  } catch (e) {
    console.error('Error saving game to gallery', e);
  }
}

/**
 * Remove a specific game by ID from the gallery and synchronize both areas
 */
export function removeGameFromGallery(idOrKey: string): void {
  deleteGamePermanently(idOrKey).catch(() => {});
}

/**
 * Permanently deletes a game from local storage, sequence history, and Firestore
 */
export async function deleteGamePermanently(idOrItem: string | GameSequenceItem): Promise<boolean> {
  if (typeof window === 'undefined' || !idOrItem) return false;

  const targetId = typeof idOrItem === 'string' ? idOrItem : idOrItem.id;
  const targetRound = typeof idOrItem === 'object' ? idOrItem.round : undefined;
  const targetTimestamp = typeof idOrItem === 'object' ? idOrItem.timestamp : undefined;

  try {
    const raw = localStorage.getItem(STORAGE_KEY_SAVED_GAMES_GALLERY);
    const current: GameSequenceItem[] = raw ? JSON.parse(raw) : [];

    const foundItem = current.find((g) => {
      if (!g) return false;
      if (targetId && (g.id === targetId || `${g.round}_${g.timestamp}` === targetId)) return true;
      if (typeof idOrItem === 'string' && (String(g.round) === idOrItem || `game_${g.round}_${g.mode || g.sheetType}` === idOrItem)) return true;
      if (targetRound !== undefined && targetTimestamp !== undefined && g.round === targetRound && g.timestamp === targetTimestamp) return true;
      return false;
    });

    const docId = foundItem?.id || targetId;

    const filtered = current.filter((g) => {
      if (!g) return false;
      if (docId && g.id === docId) return false;
      if (targetId && g.id === targetId) return false;
      if (targetRound !== undefined && targetTimestamp !== undefined && g.round === targetRound && g.timestamp === targetTimestamp) return false;
      if (typeof idOrItem === 'string') {
        if (`${g.round}_${g.timestamp}` === idOrItem) return false;
        if (`game_${g.round}_${g.mode || g.sheetType}` === idOrItem) return false;
        if (String(g.round) === idOrItem) return false;
      }
      return true;
    });

    safeSetItem(STORAGE_KEY_SAVED_GAMES_GALLERY, JSON.stringify(filtered));

    // Sync sequence storage keys
    const seq90 = filtered
      .filter((g) => g.mode === '90' || g.sheetType === 'traditional-90')
      .sort((a, b) => (a.round || 0) - (b.round || 0));
    safeSetItem(STORAGE_KEY_SEQUENCE_90, JSON.stringify(sanitizeSequenceForStorage(seq90)));

    const seq75 = filtered
      .filter((g) => g.mode === '75' || g.sheetType === 'multipliers-15')
      .sort((a, b) => (a.round || 0) - (b.round || 0));
    safeSetItem(STORAGE_KEY_SEQUENCE_75, JSON.stringify(sanitizeSequenceForStorage(seq75)));

    // Delete Firestore document asynchronously
    try {
      if (docId) {
        await deleteDoc(doc(db, 'saved_games', docId)).catch(() => {});
      }
      if (targetId && targetId !== docId) {
        await deleteDoc(doc(db, 'saved_games', targetId)).catch(() => {});
      }
    } catch (fsErr) {
      console.warn('Firestore game delete error:', fsErr);
    }

    window.dispatchEvent(
      new CustomEvent('bingo_saved_games_updated', {
        detail: { total: filtered.length, deletedId: docId || targetId },
      })
    );

    return true;
  } catch (e) {
    console.error('Error removing game from gallery', e);
    return false;
  }
}

/**
 * Clear all saved games in gallery and synchronize both areas
 */
export function clearAllSavedGamesGallery(filterMode?: 'all' | '75' | '90'): void {
  if (typeof window === 'undefined') return;

  try {
    if (!filterMode || filterMode === 'all') {
      localStorage.setItem(STORAGE_KEY_SAVED_GAMES_GALLERY, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEY_SEQUENCE_75, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEY_SEQUENCE_90, JSON.stringify([]));

      // Asynchronously wipe all saved_games from Firestore
      try {
        getDocs(collection(db, 'saved_games'))
          .then((snap) => {
            snap.forEach((d) => {
              deleteDoc(d.ref).catch(() => {});
            });
          })
          .catch(() => {});
      } catch {}

      window.dispatchEvent(
        new CustomEvent('bingo_saved_games_updated', {
          detail: { total: 0 },
        })
      );
    } else if (filterMode === '75') {
      const current = getSavedGamesGallery();
      const filtered = current.filter((g) => {
        if (g.mode === '75' || g.sheetType === 'multipliers-15') {
          if (g.id) deleteDoc(doc(db, 'saved_games', g.id)).catch(() => {});
          return false;
        }
        return true;
      });
      localStorage.setItem(STORAGE_KEY_SAVED_GAMES_GALLERY, JSON.stringify(filtered));
      localStorage.setItem(STORAGE_KEY_SEQUENCE_75, JSON.stringify([]));
      window.dispatchEvent(
        new CustomEvent('bingo_saved_games_updated', {
          detail: { total: filtered.length },
        })
      );
    } else if (filterMode === '90') {
      const current = getSavedGamesGallery();
      const filtered = current.filter((g) => {
        if (g.mode === '90' || g.sheetType === 'traditional-90') {
          if (g.id) deleteDoc(doc(db, 'saved_games', g.id)).catch(() => {});
          return false;
        }
        return true;
      });
      localStorage.setItem(STORAGE_KEY_SAVED_GAMES_GALLERY, JSON.stringify(filtered));
      localStorage.setItem(STORAGE_KEY_SEQUENCE_90, JSON.stringify([]));
      window.dispatchEvent(
        new CustomEvent('bingo_saved_games_updated', {
          detail: { total: filtered.length },
        })
      );
    }
  } catch (e) {
    console.error('Error clearing saved games gallery', e);
  }
}

