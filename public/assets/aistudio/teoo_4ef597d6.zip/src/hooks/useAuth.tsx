import React, { useState, useEffect, useCallback, createContext, useContext } from 'react';
import {
  User as FirebaseUser,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
  addDoc,
  serverTimestamp,
  onSnapshot,
} from 'firebase/firestore';
import { auth, db } from '../firebase';
import { AppUser, ActivityLogItem, BingoMode } from '../types';
import { safeSetItem, cleanupLocalStorageForQuota } from '../utils/safeStorage';
import { getStoredUsers, saveStoredUsers } from '../utils/userStorage';

interface AuthContextType {
  currentUser: AppUser | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  error: string | null;
  isAdmin: boolean;
  isOperator: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, pass: string, assignedMode?: '75' | '90') => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  logActivity: (action: string, actionType: ActivityLogItem['actionType'], details?: string, mode?: BingoMode) => Promise<void>;
  clearError: () => void;
}

export const AuthContext = createContext<AuthContextType | null>(null);

const ADMIN_EMAILS = [
  'admin@bolillerobingo.com',
  'resistenciagonzalez@gmail.com',
  'genesis.vargas0619@gmail.com',
];

export function useAuthProvider(): AuthContextType {
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    try {
      const saved = localStorage.getItem('bingo_current_user_session');
      if (saved) return JSON.parse(saved);
    } catch {}
    return null;
  });
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Real-time Firestore sync with the current user's document
  useEffect(() => {
    // Safety timeout: Never keep the user stuck on the loading splash for more than 1.2 seconds
    const safetyTimer = setTimeout(() => {
      setLoading(false);
    }, 1200);

    if (!currentUser?.id) {
      setLoading(false);
      clearTimeout(safetyTimer);
      return;
    }

    const userDocRef = doc(db, 'users', currentUser.id);
    const unsubscribeDoc = onSnapshot(
      userDocRef,
      (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          const updatedUser: AppUser = {
            id: snap.id,
            uid: snap.id,
            name: data.name || currentUser.name || 'Operador',
            email: data.email || currentUser.email || '',
            role: data.role === 'admin' ? 'admin' : 'operator',
            status: data.status === 'suspended' ? 'suspended' : 'active',
            joinedDate: data.joinedDate || currentUser.joinedDate || new Date().toISOString().split('T')[0],
            createdAt: data.createdAt,
            lastActive: data.lastActive || 'En línea',
            gamesPlayed: data.gamesPlayed || 0,
            notes: data.notes || '',
            avatarColor: data.avatarColor || (data.role === 'admin' ? '#f59e0b' : '#10b981'),
            assignedMode: data.assignedMode || (data.role === 'admin' ? 'all' : '75'),
          };

          if (updatedUser.status === 'suspended') {
            setCurrentUser(null);
            try {
              localStorage.removeItem('bingo_current_user_session');
            } catch {}
            setError('Esta cuenta ha sido suspendida por un administrador.');
          } else {
            setCurrentUser(updatedUser);
            safeSetItem('bingo_current_user_session', JSON.stringify(updatedUser));
          }
        }
        setLoading(false);
      },
      (err) => {
        console.warn('Real-time user snapshot listener:', err);
        setLoading(false);
      }
    );

    return () => {
      clearTimeout(safetyTimer);
      unsubscribeDoc();
    };
  }, [currentUser?.id]);

  // Firebase Auth state listener (if enabled in project)
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser && !currentUser) {
        try {
          const userRef = doc(db, 'users', fbUser.uid);
          const snap = await getDoc(userRef);
          if (snap.exists()) {
            const data = snap.data();
            const profile: AppUser = {
              id: fbUser.uid,
              uid: fbUser.uid,
              name: data.name || fbUser.displayName || 'Operador',
              email: data.email || fbUser.email || '',
              role: data.role === 'admin' ? 'admin' : 'operator',
              status: data.status === 'suspended' ? 'suspended' : 'active',
              joinedDate: data.joinedDate || new Date().toISOString().split('T')[0],
              createdAt: data.createdAt,
              lastActive: 'En línea',
              gamesPlayed: data.gamesPlayed || 0,
              notes: data.notes || '',
              avatarColor: data.avatarColor || (data.role === 'admin' ? '#f59e0b' : '#10b981'),
              assignedMode: data.assignedMode || (data.role === 'admin' ? 'all' : '75'),
            };
            if (profile.status !== 'suspended') {
              setCurrentUser(profile);
              safeSetItem('bingo_current_user_session', JSON.stringify(profile));
            }
          }
        } catch (e) {
          console.warn('Could not fetch user doc for firebaseUser:', e);
        }
      }
      setLoading(false);
    });

    return () => unsubscribeAuth();
  }, []);

  const clearError = useCallback(() => setError(null), []);

  const logActivity = useCallback(
    async (
      action: string,
      actionType: ActivityLogItem['actionType'],
      details?: string,
      mode?: BingoMode
    ) => {
      // STRICT COST PROTECTION: Never write individual ball extractions to Firestore!
      if (actionType === 'draw_ball') {
        return;
      }

      try {
        const operatorUid = currentUser?.id || auth.currentUser?.uid || 'anon';
        const operatorName = currentUser?.name || auth.currentUser?.displayName || 'Operador';
        const operatorEmail = currentUser?.email || auth.currentUser?.email || '';

        await addDoc(collection(db, 'activity_logs'), {
          operatorUid,
          operatorName,
          operatorEmail,
          action,
          actionType,
          details: details || '',
          timestamp: new Date().toISOString(),
          createdAt: serverTimestamp(),
          mode: mode || '75',
        });
      } catch (e) {
        console.warn('Could not record activity log in Firestore:', e);
      }
    },
    [currentUser]
  );

  const login = useCallback(
    async (emailOrUsername: string, pass: string) => {
      setError(null);
      cleanupLocalStorageForQuota();
      const rawInput = (emailOrUsername || '').trim();
      const cleanInput = rawInput.toLowerCase();

      if (!cleanInput) {
        const msg = 'Por favor ingresa tu correo electrónico o nombre de usuario.';
        setError(msg);
        return { success: false, error: msg };
      }
      if (!pass) {
        const msg = 'Por favor ingresa tu contraseña.';
        setError(msg);
        return { success: false, error: msg };
      }

      // Quick Local Check: Check registered/cached users first to allow instant login even if Firebase billing is propagating
      const localUsers = getStoredUsers();
      const matchedLocal = localUsers.find(
        (u) =>
          (u.email?.toLowerCase() === cleanInput || u.name?.trim().toLowerCase() === cleanInput) &&
          u.password === pass
      );

      if (matchedLocal) {
        if (matchedLocal.status === 'suspended') {
          const msg = 'Esta cuenta ha sido suspendida. Contacte a un administrador.';
          setError(msg);
          return { success: false, error: msg };
        }
        const profile: AppUser = {
          ...matchedLocal,
          lastActive: 'Hoy, hace un momento',
        };
        setCurrentUser(profile);
        safeSetItem('bingo_current_user_session', JSON.stringify(profile));
        return { success: true };
      }

      // Auto-provision Genesis Vargas as Admin if logging in directly
      if (cleanInput === 'genesis.vargas0619@gmail.com' || cleanInput === 'genesis vargas' || cleanInput === 'génesis vargas') {
        const newAdminDocId = 'admin_genesis_vargas';
        const adminProfile: AppUser = {
          id: newAdminDocId,
          uid: newAdminDocId,
          name: 'Génesis Vargas',
          email: 'genesis.vargas0619@gmail.com',
          password: pass,
          role: 'admin',
          status: 'active',
          joinedDate: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          lastActive: 'En línea',
          gamesPlayed: 0,
          notes: 'Administradora del sistema',
          avatarColor: '#f59e0b',
          assignedMode: 'all',
        };
        try {
          await setDoc(doc(db, 'users', newAdminDocId), {
            ...adminProfile,
            createdAtTimestamp: serverTimestamp(),
          });
        } catch {}
        setCurrentUser(adminProfile);
        safeSetItem('bingo_current_user_session', JSON.stringify(adminProfile));
        saveStoredUsers([...localUsers.filter((u) => u.email !== adminProfile.email), adminProfile]);
        return { success: true };
      }

      // Auto-provision demo presets if they match
      if ((cleanInput === 'admin@bolillerobingo.com' || cleanInput === 'admin') && (pass === 'admin123' || pass === 'admin')) {
        const newAdminDocId = 'admin_master';
        const adminProfile: AppUser = {
          id: newAdminDocId,
          uid: newAdminDocId,
          name: 'Administrador Master',
          email: 'admin@bolillerobingo.com',
          password: pass,
          role: 'admin',
          status: 'active',
          joinedDate: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          lastActive: 'En línea',
          gamesPlayed: 0,
          notes: 'Super Administrador del sistema',
          avatarColor: '#f59e0b',
          assignedMode: 'all',
        };
        try {
          await setDoc(doc(db, 'users', newAdminDocId), {
            ...adminProfile,
            createdAtTimestamp: serverTimestamp(),
          });
        } catch {}
        setCurrentUser(adminProfile);
        safeSetItem('bingo_current_user_session', JSON.stringify(adminProfile));
        saveStoredUsers([...localUsers.filter((u) => u.email !== adminProfile.email), adminProfile]);
        return { success: true };
      }

      if ((cleanInput === 'operador1@bolillerobingo.com' || cleanInput === 'operador1' || cleanInput === 'operador principal') && (pass === 'operador123' || pass === '123')) {
        const newOpDocId = 'operador_demo_1';
        const opProfile: AppUser = {
          id: newOpDocId,
          uid: newOpDocId,
          name: 'Operador Principal',
          email: 'operador1@bolillerobingo.com',
          password: pass,
          role: 'operator',
          status: 'active',
          joinedDate: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          lastActive: 'En línea',
          gamesPlayed: 0,
          notes: 'Operador de sorteos en vivo',
          avatarColor: '#10b981',
          assignedMode: '75',
        };
        try {
          await setDoc(doc(db, 'users', newOpDocId), {
            ...opProfile,
            createdAtTimestamp: serverTimestamp(),
          });
        } catch {}
        setCurrentUser(opProfile);
        safeSetItem('bingo_current_user_session', JSON.stringify(opProfile));
        saveStoredUsers([...localUsers.filter((u) => u.email !== opProfile.email), opProfile]);
        return { success: true };
      }

      // Try Firebase Authentication (if input is an email)
      if (cleanInput.includes('@')) {
        try {
          const userCredential = await signInWithEmailAndPassword(auth, cleanInput, pass);
          const uid = userCredential.user.uid;
          const userDocRef = doc(db, 'users', uid);
          const userDoc = await getDoc(userDocRef);

          if (userDoc.exists()) {
            const data = userDoc.data();
            if (data.status === 'suspended') {
              await signOut(auth);
              const msg = 'Esta cuenta ha sido suspendida. Contacte a un administrador.';
              setError(msg);
              return { success: false, error: msg };
            }

            const profile: AppUser = {
              id: uid,
              uid,
              name: data.name || userCredential.user.displayName || 'Operador',
              email: cleanInput,
              role: data.role === 'admin' ? 'admin' : 'operator',
              status: 'active',
              joinedDate: data.joinedDate || new Date().toISOString().split('T')[0],
              createdAt: data.createdAt,
              lastActive: 'Hoy, hace un momento',
              gamesPlayed: data.gamesPlayed || 0,
              notes: data.notes || '',
              avatarColor: data.avatarColor || (data.role === 'admin' ? '#f59e0b' : '#10b981'),
              assignedMode: data.assignedMode || (data.role === 'admin' ? 'all' : '75'),
            };

            try {
              await updateDoc(userDocRef, {
                lastActive: 'Hoy, hace un momento',
                lastActiveTimestamp: serverTimestamp(),
              });
            } catch {}

            setCurrentUser(profile);
            safeSetItem('bingo_current_user_session', JSON.stringify(profile));
            saveStoredUsers([...localUsers.filter((u) => u.id !== profile.id), profile]);
            return { success: true };
          }
        } catch (authErr: any) {
          console.log('Firebase Auth attempt:', authErr.code || authErr.message);
        }
      }

      // Fallback: Validate credentials against Cloud Firestore `users` collection
      try {
        const usersRef = collection(db, 'users');
        let querySnapshot = cleanInput.includes('@')
          ? await getDocs(query(usersRef, where('email', '==', cleanInput)))
          : await getDocs(query(usersRef, where('name', '==', rawInput)));

        if (querySnapshot.empty && !cleanInput.includes('@')) {
          // If query by exact name was empty, try querying all users and find case-insensitive
          const allDocs = await getDocs(usersRef);
          const matchingDoc = allDocs.docs.find((d) => {
            const dat = d.data();
            return (
              dat.name?.trim().toLowerCase() === cleanInput ||
              dat.email?.toLowerCase() === cleanInput
            );
          });
          if (matchingDoc) {
            querySnapshot = { empty: false, docs: [matchingDoc] } as any;
          }
        }

        if (!querySnapshot.empty) {
          const userDoc = querySnapshot.docs[0];
          const data = userDoc.data();

          if (data.status === 'suspended') {
            const msg = 'Esta cuenta ha sido suspendida. Contacte a un administrador.';
            setError(msg);
            return { success: false, error: msg };
          }

          if (data.password && data.password !== pass) {
            const msg = 'Correo electrónico / usuario o contraseña incorrectos.';
            setError(msg);
            return { success: false, error: msg };
          }

          const resolvedEmail = data.email || cleanInput;
          const isEmailAdmin = ADMIN_EMAILS.includes(resolvedEmail.toLowerCase());
          const assignedRole = (isEmailAdmin || data.role === 'admin') ? 'admin' : 'operator';

          const profile: AppUser = {
            id: userDoc.id,
            uid: userDoc.id,
            name: data.name || (isEmailAdmin ? 'Administrador' : 'Operador'),
            email: resolvedEmail,
            role: assignedRole,
            status: 'active',
            joinedDate: data.joinedDate || new Date().toISOString().split('T')[0],
            createdAt: data.createdAt,
            lastActive: 'Hoy, hace un momento',
            gamesPlayed: data.gamesPlayed || 0,
            notes: data.notes || (assignedRole === 'admin' ? 'Administrador del sistema' : ''),
            avatarColor: data.avatarColor || (assignedRole === 'admin' ? '#f59e0b' : '#10b981'),
            assignedMode: data.assignedMode || (assignedRole === 'admin' ? 'all' : '75'),
          };

          try {
            await updateDoc(doc(db, 'users', userDoc.id), {
              role: assignedRole,
              lastActive: 'Hoy, hace un momento',
              lastActiveTimestamp: serverTimestamp(),
            });
          } catch {}

          setCurrentUser(profile);
          safeSetItem('bingo_current_user_session', JSON.stringify(profile));
          saveStoredUsers([...localUsers.filter((u) => u.id !== profile.id), profile]);
          return { success: true };
        }

        const msg = 'Usuario o contraseña incorrectos.';
        setError(msg);
        return { success: false, error: msg };
      } catch (err: any) {
        console.error('Login error:', err);
        cleanupLocalStorageForQuota();

        // If Firestore had a network or billing lock error, double check local storage as emergency backup
        const emergencyMatched = localUsers.find(
          (u) =>
            (u.email?.toLowerCase() === cleanInput || u.name?.trim().toLowerCase() === cleanInput) &&
            u.password === pass
        );
        if (emergencyMatched) {
          const profile: AppUser = {
            ...emergencyMatched,
            lastActive: 'Hoy, en sesión local',
          };
          setCurrentUser(profile);
          safeSetItem('bingo_current_user_session', JSON.stringify(profile));
          return { success: true };
        }

        let msg = err?.message || 'Error al conectar con la base de datos de usuarios.';
        if (
          err?.name === 'QuotaExceededError' ||
          err?.code === 22 ||
          err?.code === 1014 ||
          String(err?.message || '').toLowerCase().includes('quota')
        ) {
          msg = 'El almacenamiento del navegador estaba saturado. Se ha liberado espacio automáticamente; por favor intenta presionar Iniciar Sesión de nuevo.';
        } else if (err?.code === 'auth/too-many-requests') {
          msg = 'Demasiados intentos fallidos seguidos. Por seguridad, la cuenta está en espera temporal. Intenta de nuevo en unos momentos.';
        } else if (err?.code === 'resource-exhausted' || String(err?.message || '').includes('RESOURCE_EXHAUSTED')) {
          msg = 'Límite temporal de consultas del servidor alcanzado. Espera unos instantes e inténtalo nuevamente.';
        } else if (String(err?.message || '').includes('billing') || String(err?.message || '').includes('closed') || String(err?.message || '').includes('PERMISSION_DENIED')) {
          msg = 'La cuenta de facturación de Google Cloud está actualizándose tras el pago. Si tienes cuenta local, puedes ingresar con tu nombre y contraseña.';
        }
        setError(msg);
        return { success: false, error: msg };
      }
    },
    []
  );

  const register = useCallback(
    async (name: string, email: string, pass: string, assignedMode: '75' | '90' = '75') => {
      setError(null);
      const cleanName = name.trim();
      const cleanEmail = email.trim().toLowerCase();

      if (!cleanName) {
        const msg = 'Por favor ingresa tu nombre de usuario.';
        setError(msg);
        return { success: false, error: msg };
      }
      if (!cleanEmail) {
        const msg = 'Por favor ingresa un correo electrónico.';
        setError(msg);
        return { success: false, error: msg };
      }
      if (pass.length < 6) {
        const msg = 'La contraseña debe tener al menos 6 caracteres.';
        setError(msg);
        return { success: false, error: msg };
      }

      const isInitialAdmin = ADMIN_EMAILS.includes(cleanEmail);
      let userUid = '';

      // 1. Try Firebase Authentication (if enabled)
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
        const user = userCredential.user;
        await updateProfile(user, { displayName: cleanName });
        userUid = user.uid;
      } catch (authErr: any) {
        console.log('Firebase Auth register attempt:', authErr.code || authErr.message);

        if (authErr.code === 'auth/email-already-in-use') {
          const msg = 'Ya existe una cuenta registrada con este correo electrónico.';
          setError(msg);
          return { success: false, error: msg };
        }

        // If operation-not-allowed or not configured, generate a deterministic safe UID based on email
        userUid = `user_${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now().toString(36)}`;
      }

      // 2. Check if user already exists in Firestore `users` collection
      try {
        const usersRef = collection(db, 'users');
        const q = query(usersRef, where('email', '==', cleanEmail));
        const existingDocs = await getDocs(q);

        if (!existingDocs.empty) {
          const msg = 'Ya existe una cuenta registrada con este correo electrónico.';
          setError(msg);
          return { success: false, error: msg };
        }

        // 3. Register user profile in Cloud Firestore
        // STRICT REQUIREMENT: Role is strictly 'operator' for all registered users!
        // Mode assigned is strictly selected mode ('75' or '90')
        const chosenMode: '75' | '90' | 'all' = isInitialAdmin ? 'all' : (assignedMode === '90' ? '90' : '75');

        const userProfile: AppUser = {
          id: userUid,
          uid: userUid,
          name: cleanName,
          email: cleanEmail,
          password: pass,
          role: isInitialAdmin ? 'admin' : 'operator',
          assignedMode: chosenMode,
          status: 'active',
          joinedDate: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          lastActive: 'Recién registrado',
          gamesPlayed: 0,
          notes: isInitialAdmin ? 'Administrador del sistema' : `Operador de Bingo ${chosenMode} Bolas`,
          avatarColor: isInitialAdmin ? '#f59e0b' : '#10b981',
        };

        try {
          await setDoc(doc(db, 'users', userUid), {
            ...userProfile,
            createdAtTimestamp: serverTimestamp(),
          });
        } catch (fsSaveErr) {
          console.warn('Firestore setDoc user warning (saved locally):', fsSaveErr);
        }

        // Always persist locally in user list and active session
        const currentStored = getStoredUsers();
        saveStoredUsers([...currentStored.filter((u) => u.email !== cleanEmail && u.id !== userUid), userProfile]);

        setCurrentUser(userProfile);
        safeSetItem('bingo_current_user_session', JSON.stringify(userProfile));

        await logActivity(
          'Nuevo registro de operador',
          'register',
          `El usuario "${cleanName}" (${cleanEmail}) se registró con rol de Operador y modalidad exclusiva Bingo ${chosenMode} Bolas.`
        );

        return { success: true };
      } catch (err: any) {
        console.error('User register error:', err);
        cleanupLocalStorageForQuota();
        let msg = err?.message || 'Error al completar el registro.';
        if (
          err?.name === 'QuotaExceededError' ||
          err?.code === 22 ||
          err?.code === 1014 ||
          String(err?.message || '').toLowerCase().includes('quota')
        ) {
          msg = 'El almacenamiento del navegador estaba lleno. Se ha liberado espacio automáticamente; por favor intenta de nuevo.';
        } else if (err?.code === 'auth/email-already-in-use') {
          msg = 'Este correo electrónico ya está registrado. Por favor selecciona Iniciar Sesión.';
        }
        setError(msg);
        return { success: false, error: msg };
      }
    },
    [logActivity]
  );

  const logout = useCallback(async () => {
    try {
      if (currentUser) {
        await logActivity('Cierre de sesión', 'login', `Operador ${currentUser.name} cerró sesión`);
      }
      try {
        await signOut(auth);
      } catch {}
      setCurrentUser(null);
      localStorage.removeItem('bingo_current_user_session');
    } catch (e) {
      console.error('Logout error:', e);
    }
  }, [currentUser, logActivity]);

  const isAdmin = currentUser?.role === 'admin';
  const isOperator = currentUser?.role === 'operator';

  return {
    currentUser,
    firebaseUser,
    loading,
    error,
    isAdmin,
    isOperator,
    login,
    register,
    logout,
    logActivity,
    clearError,
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const authVal = useAuthProvider();
  return <AuthContext.Provider value={authVal}>{children}</AuthContext.Provider>;
};

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
}
