import { AppUser } from '../types';
import { safeSetItem } from './safeStorage';

export const USERS_STORAGE_KEY = 'bingo_master_admin_users';
export const CURRENT_USER_STORAGE_KEY = 'bingo_current_user_session';

export const DEFAULT_USERS: AppUser[] = [
  {
    id: 'u-admin-1',
    name: 'Organizador Principal',
    email: 'admin@bolillerobingo.com',
    password: 'admin',
    role: 'admin',
    status: 'active',
    joinedDate: '2025-01-10',
    lastActive: 'Hoy, en sesión activa',
    gamesPlayed: 48,
    notes: 'Anfitrión principal de las salas y sorteos en vivo.',
    avatarColor: '#f59e0b',
  },
  {
    id: 'u-mod-2',
    name: 'Carlos Mendoza',
    email: 'carlos.m@bingo.net',
    password: 'mod',
    role: 'operator',
    status: 'active',
    joinedDate: '2025-01-15',
    lastActive: 'Hoy, hace 25 min',
    gamesPlayed: 32,
    notes: 'Operador de sorteos y verificación de planillas.',
    avatarColor: '#3b82f6',
  },
  {
    id: 'u-usr-3',
    name: 'María Elena Gómez',
    email: 'maria.gomez@gmail.com',
    password: '123',
    role: 'operator',
    status: 'active',
    joinedDate: '2025-02-01',
    lastActive: 'Ayer',
    gamesPlayed: 24,
    notes: 'Operadora en sorteos 75 y 90 bolas.',
    avatarColor: '#ec4899',
  },
  {
    id: 'u-usr-4',
    name: 'Roberto Silva',
    email: 'roberto_silva@hotmail.com',
    password: '123',
    role: 'operator',
    status: 'active',
    joinedDate: '2025-02-12',
    lastActive: 'Hace 3 días',
    gamesPlayed: 15,
    notes: 'Operador de mesas comunitarias.',
    avatarColor: '#10b981',
  },
  {
    id: 'u-usr-5',
    name: 'Lucía Fernández',
    email: 'lucia.fer@outlook.com',
    password: '123',
    role: 'operator',
    status: 'active',
    joinedDate: '2025-02-20',
    lastActive: 'Hoy, hace 2 horas',
    gamesPlayed: 19,
    notes: 'Operadora de cartones y planillas.',
    avatarColor: '#8b5cf6',
  },
  {
    id: 'u-usr-6',
    name: 'Andrés Valenzuela',
    email: 'andres.val@gmail.com',
    password: '123',
    role: 'operator',
    status: 'suspended',
    joinedDate: '2025-01-22',
    lastActive: 'Hace 2 semanas',
    gamesPlayed: 6,
    notes: 'Cuenta suspendida por conducta indebida en chat.',
    avatarColor: '#ef4444',
  },
];

export function getStoredUsers(): AppUser[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (raw) {
      const parsed: AppUser[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading users from storage:', err);
  }
  return DEFAULT_USERS;
}

export function saveStoredUsers(users: AppUser[]): void {
  try {
    safeSetItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Error saving users to storage:', err);
  }
}

export function getCurrentUser(): AppUser | null {
  try {
    const raw = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
    if (raw) {
      const parsed: AppUser = JSON.parse(raw);
      if (parsed && parsed.id) {
        // Return freshly synchronized user from user list in case status or role changed
        const allUsers = getStoredUsers();
        const found = allUsers.find((u) => u.id === parsed.id);
        return found || parsed;
      }
    }
  } catch (err) {
    console.error('Error reading current user:', err);
  }
  // Default to Admin logged in so the user can immediately test everything
  return DEFAULT_USERS[0];
}

export function setCurrentUser(user: AppUser | null): void {
  try {
    if (user) {
      safeSetItem(CURRENT_USER_STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_STORAGE_KEY);
    }
  } catch (err) {
    console.error('Error saving current user:', err);
  }
}

export function authenticateUser(
  emailOrName: string,
  passwordInput: string
): { success: boolean; user?: AppUser; error?: string } {
  const users = getStoredUsers();
  const search = emailOrName.trim().toLowerCase();

  const user = users.find(
    (u) =>
      u.email.toLowerCase() === search ||
      u.name.toLowerCase() === search
  );

  if (!user) {
    return { success: false, error: 'Usuario o correo electrónico no encontrado.' };
  }

  if (user.status === 'suspended') {
    return {
      success: false,
      error: 'Esta cuenta ha sido suspendida. Contacte al administrador.',
    };
  }

  // If user has a password set, verify it
  if (user.password && user.password !== passwordInput.trim()) {
    return { success: false, error: 'Contraseña incorrecta. Inténtalo nuevamente.' };
  }

  // Update last active
  const updatedUser: AppUser = {
    ...user,
    lastActive: 'Hoy, hace un momento',
  };

  const updatedList = users.map((u) => (u.id === user.id ? updatedUser : u));
  saveStoredUsers(updatedList);
  setCurrentUser(updatedUser);

  return { success: true, user: updatedUser };
}
