export interface PlayerColorSpec {
  name: string;
  hex: string;
  border: string;
  text: string;
  darkText: boolean;
}

/**
 * Paleta de colores vivos, brillantes y saturados para los jugadores (NO tonos pasteles ni repetidos).
 * Al menos 30 colores únicos diseñados para resaltar con máxima claridad en las celdas y filas del cartón y pantallas.
 */
export const VIBRANT_PLAYER_COLORS: PlayerColorSpec[] = [
  { name: 'Amarillo Neón', hex: '#ffe600', border: '#ca8a04', text: '#000000', darkText: true },
  { name: 'Naranja Fuego', hex: '#ff5500', border: '#c2410c', text: '#ffffff', darkText: false },
  { name: 'Verde Lima Eléctrico', hex: '#84cc16', border: '#4d7c0f', text: '#000000', darkText: true },
  { name: 'Cyan Brillante', hex: '#00d2ff', border: '#0284c7', text: '#000000', darkText: true },
  { name: 'Fucsia / Rosa Neón', hex: '#ff007f', border: '#be123c', text: '#ffffff', darkText: false },
  { name: 'Verde Manzana Vivo', hex: '#22c55e', border: '#15803d', text: '#ffffff', darkText: false },
  { name: 'Azul Eléctrico', hex: '#2563eb', border: '#1d4ed8', text: '#ffffff', darkText: false },
  { name: 'Violeta Intenso', hex: '#7c3aed', border: '#5b21b6', text: '#ffffff', darkText: false },
  { name: 'Rojo Escarlata', hex: '#ef4444', border: '#b91c1c', text: '#ffffff', darkText: false },
  { name: 'Turquesa Neón', hex: '#00f0d4', border: '#0d9488', text: '#000000', darkText: true },
  { name: 'Púrpura Vibrante', hex: '#9333ea', border: '#6b21a8', text: '#ffffff', darkText: false },
  { name: 'Esmeralda Radiante', hex: '#059669', border: '#047857', text: '#ffffff', darkText: false },
  { name: 'Ámbar Solar', hex: '#f59e0b', border: '#b45309', text: '#000000', darkText: true },
  { name: 'Magenta Eléctrico', hex: '#d946ef', border: '#a21caf', text: '#ffffff', darkText: false },
  { name: 'Azul Cobalto', hex: '#1d4ed8', border: '#1e40af', text: '#ffffff', darkText: false },
  { name: 'Oro Brillante', hex: '#eab308', border: '#a16207', text: '#000000', darkText: true },
  { name: 'Naranja Neón', hex: '#fb923c', border: '#ea580c', text: '#000000', darkText: true },
  { name: 'Coral Intenso', hex: '#f43f5e', border: '#be123c', text: '#ffffff', darkText: false },
  { name: 'Verde Flúor', hex: '#4ade80', border: '#16a34a', text: '#000000', darkText: true },
  { name: 'Celeste Vivo', hex: '#38bdf8', border: '#0284c7', text: '#000000', darkText: true },
  { name: 'Índigo Vibrante', hex: '#6366f1', border: '#4338ca', text: '#ffffff', darkText: false },
  { name: 'Rubí Radiante', hex: '#dc2626', border: '#991b1b', text: '#ffffff', darkText: false },
  { name: 'Aguamarina Profundo', hex: '#0d9488', border: '#115e59', text: '#ffffff', darkText: false },
  { name: 'Rosa Chicle', hex: '#ec4899', border: '#9d174d', text: '#ffffff', darkText: false },
  { name: 'Menta Luminosa', hex: '#10b981', border: '#065f46', text: '#ffffff', darkText: false },
  { name: 'Zafiro Real', hex: '#0284c7', border: '#075985', text: '#ffffff', darkText: false },
  { name: 'Mostaza Dorada', hex: '#d97706', border: '#92400e', text: '#000000', darkText: true },
  { name: 'Burdeos Neón', hex: '#be123c', border: '#881337', text: '#ffffff', darkText: false },
  { name: 'Ciruela Mística', hex: '#a21caf', border: '#701a75', text: '#ffffff', darkText: false },
  { name: 'Verde Bosque Eléctrico', hex: '#15803d', border: '#166534', text: '#ffffff', darkText: false },
];

/**
 * Retorna color de texto adecuado (blanco o negro oscuro) para un fondo dado.
 */
export function getContrastTextColor(hexColor?: string): string {
  if (!hexColor) return '#0f172a';
  const clean = hexColor.replace('#', '');
  if (clean.length === 3) {
    const r = parseInt(clean[0] + clean[0], 16);
    const g = parseInt(clean[1] + clean[1], 16);
    const b = parseInt(clean[2] + clean[2], 16);
    const yiq = (r * 299 + g * 587 + b * 114) / 1000;
    return yiq >= 150 ? '#000000' : '#ffffff';
  }
  if (clean.length === 6) {
    const r = parseInt(clean.substring(0, 2), 16);
    const g = parseInt(clean.substring(2, 4), 16);
    const b = parseInt(clean.substring(4, 6), 16);
    const yiq = (r * 299 + g * 587 + b * 114) / 1000;
    return yiq >= 150 ? '#000000' : '#ffffff';
  }
  return '#000000';
}
